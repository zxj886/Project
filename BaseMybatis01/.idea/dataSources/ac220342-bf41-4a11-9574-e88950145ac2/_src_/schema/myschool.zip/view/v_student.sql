CREATE VIEW v_student AS
  SELECT
    `myschool`.`student`.`StudentNo`   AS `studentNo`,
    `myschool`.`student`.`StudentName` AS `studentName`,
    `myschool`.`student`.`Address`     AS `address`
  FROM `myschool`.`student`;
