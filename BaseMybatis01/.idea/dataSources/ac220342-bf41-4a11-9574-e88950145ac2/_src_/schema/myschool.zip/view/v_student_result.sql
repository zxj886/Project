CREATE VIEW v_student_result AS
  SELECT
    `myschool`.`student`.`StudentNo`    AS `StudentNo`,
    `myschool`.`student`.`StudentName`  AS `studentName`,
    `myschool`.`result`.`StudentResult` AS `studentResult`
  FROM `myschool`.`student`
    JOIN `myschool`.`result`
  WHERE (`myschool`.`student`.`StudentNo` = `myschool`.`result`.`StudentNo`);
