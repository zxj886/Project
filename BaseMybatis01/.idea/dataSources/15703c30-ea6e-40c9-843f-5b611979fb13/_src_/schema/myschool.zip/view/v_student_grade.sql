CREATE VIEW v_student_grade AS
  SELECT
    `myschool`.`student`.`StudentNo`   AS `studentNo`,
    `myschool`.`student`.`StudentName` AS `studentName`,
    `myschool`.`student`.`Address`     AS `address`,
    `myschool`.`grade`.`GradeName`     AS `gradeName`
  FROM `myschool`.`student`
    JOIN `myschool`.`grade`;
